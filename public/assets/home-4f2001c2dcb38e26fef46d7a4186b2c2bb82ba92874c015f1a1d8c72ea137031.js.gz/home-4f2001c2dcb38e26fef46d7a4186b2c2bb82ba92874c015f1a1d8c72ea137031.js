/*var lock = new Auth0Lock("TOJl4WP8HvCG9l5BSgimyX9NztJ0xC2T", "app50531416.auth0.com");
var callback = "http://localhost:3000/auth/auth0/callback";

function signin() {
    lock.show({
        callbackURL: "http://localhost:3000/auth/auth0/callback",
        //callbackURL: callback,
        responseType: 'code', 
        authParams: {
            scope: 'openid name email picture'
        }
    });
    }*/

// temporarily moving code to view level
